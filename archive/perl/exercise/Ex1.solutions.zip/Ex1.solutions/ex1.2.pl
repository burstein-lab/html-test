use strict;

print("I will submit my homework on time\n"x100);
