use strict;

my $email = "privmane\@tau.ac.il";
print "email is $email\n";
