package lpgTools;

use strict;

use Exporter;
use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
$VERSION = 1.00;
@ISA = qw(Exporter);
@EXPORT      = qw(lpgString);       # Symbols to autoexport (:DEFAULT tag)

use lib 'D:\workspace\pupkoSVN\scripts';
use lib 'C:\workspace\pupkoSVN\scripts';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib 'J:\workspace\pupkoSVN\scripts';
use lib '..\pupkoSVN\scripts';
use lib '..';

use util;
use csvTools;
use MapTools;
use PssmTools;

=pod
	lpgString NUMBER PREFIX DIGITS
	
	return a string of padded lpgs:
	e.g.:
	lpgString(4) 	==> "lpg0004"
	lpgString(1932) ==> "lpg1932"
	
	It is also possible to specify different PREFIX/number of DIGITS:
	lpgString(99,lpl,5) ===> "lpl00099"

=cut
sub lpgString{
	my ($lpgNumber,$lpgPrefix, $digits) = @_;
	
	$lpgNumber += 0;
	$lpgPrefix = "lpg" if not defined $lpgPrefix;
	$digits = 4 if not defined $digits;
	
 	my $lpgString = $lpgPrefix;
	# add padding zeros (I don't like printf)...
	$lpgString .= "0"x($digits-length($lpgNumber));	
	$lpgString .= $lpgNumber;
	return $lpgString;
}
1;
