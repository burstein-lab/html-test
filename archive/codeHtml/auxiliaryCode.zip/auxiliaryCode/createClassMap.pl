#!/usr/bin/perl

use strict;


use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '..';
use MapTools;

@ARGV == 3 or die "USAGE: $0 <effectors text file> <non-effector text file> <lpg map file>";

my $EFFECTOR_CLASS 		= 1;
my $NON_EFFECTOR_CLASS 	= 0; 
my $UNCLASSIFIED_CLASS 	= -1;

my($effectorText, $nonEffectorText, $lpgMapFile) = @ARGV;

my $lpg = 0;
my $class = 0;
my @lpgClassArr = ();

# Read map of lpg:  lpgMap[$i] = lpgXXXX;
my @lpgMap = MapTools::readMap($lpgMapFile);

# Set all lpg class to $UNCLASSIFIED_CLASS as default
map {$lpgClassArr[$_] = $UNCLASSIFIED_CLASS} @lpgMap;

# Read effector file
open(EFF, $effectorText) or die "Can't open $effectorText: $!";
while (<EFF>) {
	m/lpg(\d+)/;
	$lpgClassArr[$1] = $EFFECTOR_CLASS;
}
close(EFF);

# Read non-effector file
open(NON, $nonEffectorText) or die "Can't open $nonEffectorText: $!";
while (<NON>) {
	m/lpg(\d+)/;
	$lpgClassArr[$1] = $NON_EFFECTOR_CLASS;
}
close(NON);

# Print
MapTools::printMap(\@lpgClassArr);
