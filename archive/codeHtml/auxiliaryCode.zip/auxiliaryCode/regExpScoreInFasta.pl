#!/usr/bin/perl -w

use strict;

use Bio::SeqIO;

@ARGV >= 2 or die "USAGE: $0 <fasta file> <regExp> [Optional: <title> <index offset> <score 1st match> <score of additional match> <overlapping>]
<fasta file>             - The fasta file in which the regExp should be searched.
<regExp>                 - A Perl regular expression.
<title>                  - Title of the column, (default: <regExp>)
<index offset>           - Index to start (default: 0). If negative,starts that far from the end 
<1st match score>        - Score given the first match (deafult: measures frequencies frequencies)
<additional match score> - Score given for any additional score (2nd and on), (deafult: <1st match score >)
<overlapping>			 - Is the signal overlapping: (default: FALSE)
";

my($fastaFilename, $regExp, $title, $offset, $firstMatchScore, $additionalMatchScore, $overlapping) = @ARGV;
$overlapping = 0 unless defined $overlapping;
$title = $regExp unless defined $title;
$offset = 0 unless defined $offset;
$additionalMatchScore = $offset unless defined $additionalMatchScore;

# Read Fasta file.
my $fastaSeq = Bio::SeqIO->new(-file   => "<$fastaFilename", -format => 'fasta' );
print "\"$title\"\n";
while (my $seq = $fastaSeq->next_seq) {
	#get subsequence according to offset
	my $subSeq = substr($seq->seq(),$offset);
	# count number of apperanced of regExp

	my $count = 0;
	if ($overlapping){	
		$count++ while $subSeq=~ /(?=$regExp)/g;
	} else {
		$count++ while $subSeq=~ /($regExp)/g;
	}
	# firstMatchScore is undefined measure frequency
	# In such a case - make score to calculate frequency
	if (not defined $firstMatchScore) {
		$additionalMatchScore = $firstMatchScore = 1/length($subSeq); 
	}
	
	# first count = <1st match score> any additional adds <additional match score>
	my $score = 0; 
	$score = $firstMatchScore + ($count-1)*$additionalMatchScore if ($count);
	print $score;
	print "\n";
}

