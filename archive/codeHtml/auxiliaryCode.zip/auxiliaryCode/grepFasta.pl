#!/usr/bin/perl -w

use strict;

@ARGV == 2 or die "USAGE: $0 <fasta file> <expression>
The script will output all fasta sequences which contains expression in header.
Note: expression can be a PERL regular expression = )\n";

my($fastaFile, $exp) = @ARGV;

# Read Fasta file and print lines after header with expression found.
my $printFlag = 0;
open(FASTA, $fastaFile) or die "Can't open $fastaFile: $!";
while (<FASTA>) {
	# If header 
	if (/^>/) {
		# Set flag on iff xpression found
		 if (/$exp/){$printFlag = 1;}
		 else	{$printFlag = 0;}
	}
	# Print line if flag on.
	print if $printFlag;
}
close(FASTA);