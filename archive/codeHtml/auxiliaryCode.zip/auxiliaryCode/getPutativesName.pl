#!/usr/bin/perl -w

use strict;

use lib '..';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '/cygdrive/d/workspace/theEffectorsMachine';

use ReadGilsExcel;

@ARGV >= 2 or die "USAGE: getPutativesName.pl <genes list>  <effectors html file> <non effectors list>\n";

my($genesList, $html, $nonEffectors) = @ARGV;

### read putative gene names from html ###
my %descsHash = ReadGilsExcel::readPutatives2Hash($html);	

### read non effectors from list ###
open(NON, $nonEffectors) or die "Error: Can't open genes list file $nonEffectors $!";
my @nonEffectorsArr = <NON>;
chomp @nonEffectorsArr;
foreach (@nonEffectorsArr) {
	die "$_ appears both in non-effectors and on putative effectors lists\n" if defined $descsHash{$_};
	$descsHash{$_}= "**Non-Effector**"
}


#### Read genes list ####
open(GENES, $genesList) or die "Error: Can't open genes list file $genesList $!";
my @genesArr = <GENES>;
chomp @genesArr;
# get number value of the array
@genesArr = map {/(\d+)/} @genesArr;

# print putative value in hash
print "putative\n"; 
foreach (@genesArr) {$descsHash{$_}? print "$descsHash{$_}\n" : print "-\n";}
