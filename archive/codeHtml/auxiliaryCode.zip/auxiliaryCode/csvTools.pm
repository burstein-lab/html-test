package csvTools;

use strict;

use Exporter;
use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
$VERSION = 1.00;
@ISA = qw(Exporter);
@EXPORT = qw(readCsv csvArr2Hash readCsv2Hash writeCsv printCsvSubset updateCol );       # Symbols to autoexport (:DEFAULT tag)


=pod
	readCsv FILENAME

	Reads the csv file in FILENAME and insert it to an array of hashes with the headers as their keys.
	Such that:
	$csv[$i]['Name'] will return the value in the i-th row and 'name' column.
	
	The subroutine returs a reference to the cvs array.
	

=cut
sub readCsv{
	my $csvFilename = shift;
	open(CSV, $csvFilename) or die "Error: Can't open $csvFilename $!";

	# Get headers from first line.
	my $headerLine = <CSV>;
	chomp $headerLine;
	#split line and deal with "a, b"...
	my @headers = ($headerLine =~ m/\s*([^,"]+|"[^\"]+")\s*(?:,|$)/g);
	
	# Get lines into arr of [ , {header_1=> val_1, header_2=> val_2, ...,  header_n=> val_n} , ] 
	my @lineVals;
	my @csv; 
	foreach (<CSV>){
		chomp;
		@lineVals = ( m/\s*([^,"]*|"[^\"]*")\s*(?:,|$)/g);
		my %lineHash = map {$headers[$_] => $lineVals[$_]} (0..$#headers);
		push(@csv, \%lineHash);
	}
	return \@csv;
}


=pod 
	csvArr2Hash CVS_REF KEY
  
	Turn a csv array to an hash using one of the headers.
	Recives cvs array + header to be the key of the hash
	Reurns a Refernce to a hash
  
=cut
sub csvArr2Hash{
	my ($csv, $csvKey) = @_;
	my %csvHash = map {$_->{$csvKey} => $_} @{$csv};
	return \%csvHash;
}

=pod
	readCsv2Hash FILENAME, KEY
	
	Reads a csv file in FILENAME into an hash using KEY - one of the headers as a key
	Uses readCsv2Hash csvArr2Hash.
	Reurns a Refernce to a hash    
	
=cut
sub readCsv2Hash{
	my ($filename, $key) = @_;
	return csvArr2Hash(readCsv($filename),$key);
}
=pod
	writeCsv FILENAME CSV_ARRAY_REF HEADERS_ARRAY_REF
	
	Writes into FILENAME the CSV_ARRAY_REF.
	If HEADERS_ARRAY_REF is given only those columns will be printed (and in the order
	of appearance in the array).
	If HEADERS_ARRAY_REF is ommited all coulmns will be printed in a random order.
	
=cut 
sub writeCsv{
	my ($filename, $csvRef, $headersRef) = @_; 
	$headersRef = \keys %{$csvRef->[0]} if not defined $headersRef;
	
	open (FILE, ">$filename") or die "Error: can't open $filename $!...\n";
	
	my $printLine = ""; 
	
	# print headers line.
	foreach (@{$headersRef}) {$printLine .= $_.","};
	chop $printLine;
	print FILE $printLine."\n"; 
	
	# print cvs content.
	foreach my $csvRow (@{$csvRef}) {
		$printLine = "";
		foreach my $header (@{$headersRef}) {
			$printLine .= $csvRow->{$header} if defined $csvRow->{$header};
			$printLine .= ",";
		}
		chop $printLine;
		print FILE $printLine."\n";
	}
}
=pod
	writeCsv FILENAME CSV_HASH_REF HEADERS_ARRAY_REF
	
	Writes into FILENAME the CSV_HASH_REF.
	Only columns specified in HEADERS_ARRAY_REF will be printed (and in the order
	of appearance in the array).
	The order in the file is accorsing to the key of the hash.  
	
=cut 
sub writeCsvHash{
	my ($filename, $csvHashRef, $headersRef) = @_; 
	
	open (FILE, ">$filename") or die "Error: can't open $filename $!...\n";
	
	my $printLine = ""; 
	# print headers line.
	foreach (@{$headersRef}) {$printLine .= $_.","};
	chop $printLine;
	print FILE $printLine."\n"; 
	
	# print cvs content.
	foreach my $csvRow (sort keys %{$csvHashRef}) {
		$printLine = "";
		foreach my $header (@{$headersRef}) {
			$printLine .= $csvHashRef->{$csvRow}->{$header} if defined $csvHashRef->{$csvRow}->{$header};
			$printLine .= ",";
		}
		chop $printLine;
		print FILE $printLine."\n";
	}
}

=pod
	printCsv FILENAME CSV_HASH_REF HEADERS_ARRAY_REF
	
	prints CSV_HASH_REF.
=cut 
sub printCsvHash{
	my ($csvHashRef) = @_; 
	my $printLine="";
	my @headers = sort keys %{$csvHashRef->{keys %{$csvHashRef}}[0]};
	foreach (@headers) {$printLine .= $_.","};
	chop $printLine;
	print $printLine."\n";
	foreach my $csvRow (sort keys %{$csvHashRef}) {
		$printLine = "";
		foreach my $header (@headers) {
			$printLine .= $csvHashRef->{$csvRow}->{$header} if defined $csvHashRef->{$csvRow}->{$header};
			$printLine .= ",";
		}
		chop $printLine;
		print $printLine."\n";
	}
}


=pod
	printCsvSubset CSV_FILE KEY KEYS_LIST_FILE HEADER_ARR
	
	Reads CSV_FILE and print only the rows that their KEY header is specified in KEYS_LIST
	If header specidied - only header specied in HEADER_ARR will be printed 
	
=cut
sub printCsvSubset {
	my ($filename, $key, $keysListFile, @headers) = @_;
	
	my %csvHash = %{readCsv2Hash($filename, $key)};
	@headers = keys %{(values %csvHash)[0]} if ($#headers < 0);
	@headers = reverse sort @headers;
	open(LIST,$keysListFile) or die "ERROR: cannot open $keysListFile $!";
	
	my @subset;
	my $printLine="";
	foreach (@headers) {$printLine .= $_.","};
	chop $printLine;
	$printLine .= "\n";
	print $printLine;
	push(@subset, $printLine);

	foreach my $currKey (<LIST>) {
		chomp $currKey ;
		$printLine="";
		foreach (@headers) {$printLine .= $csvHash{$currKey}{$_}.","};
		chop $printLine;
		$printLine .= "\n";
		print $printLine;
		push(@subset, $printLine);
	}
	return @subset;
}

=pod
	updateCol CSV_FILE1 CSV_FILE2 KEY HEADER 
	
	Updated the column with HEADER of CSV_FILE1 according to CSV_FILE2.
	The comparison is based on the KEY column.
	
=cut
sub updateCol {
	my ($filename1, $filename2, $key, $header) = @_;
	my %csvHash1 = %{readCsv2Hash($filename1, $key)};
	my %csvHash2 = %{readCsv2Hash($filename2, $key)};
	foreach (keys %csvHash2) {
		$csvHash1{$_}{$header} = $csvHash2{$_}{$header};
	}
	return \%csvHash1;
}

=pod
	updateUndefCol CSV_FILE1 CSV_FILE2 KEY HEADER 
	
	Updated the column with HEADER of CSV_FILE1 according to CSV_FILE2 ***only if it is not defined in CSV_FILE1***
	The comparison is based on the KEY column.
	
=cut
sub updateUndefCol {
	my ($filename1, $filename2, $key, $header) = @_;
	my %csvHash1 = %{readCsv2Hash($filename1, $key)};
	my %csvHash2 = %{readCsv2Hash($filename2, $key)};
	foreach (keys %csvHash2) {
		$csvHash1{$_}{$header} = $csvHash2{$_}{$header} if not $csvHash1{$_}{$header} ;
	}
	return \%csvHash1;
}

=pod
	prefixCol CSV_FILE1 CSV_FILE2 KEY HEADER SEPERATOR
	
	Adds to the column HEADER of CSV_FILE1 as a prefix whatever is in CSV_FILE2 in the same header at the same row 
	The comparison is based on the KEY column.
	Between them SEPERATOR is inserted if given
	
=cut
sub prefixCol {
	my ($filename1, $filename2, $key, $header, $seperator) = @_;
	my %csvHash1 = %{readCsv2Hash($filename1, $key)};
	my %csvHash2 = %{readCsv2Hash($filename2, $key)};
	foreach (keys %csvHash2) {
		my $mergedCol = $csvHash2{$_}{$header} if defined $csvHash2{$_}{$header};
		$mergedCol .= $seperator if defined $seperator;
		$mergedCol .= $csvHash1{$_}{$header} if defined $csvHash1{$_}{$header};
		$csvHash1{$_}{$header} = $mergedCol if defined $mergedCol;
	}
	return \%csvHash1;
}

=pod
	transposeCsv CSV_FILE
	
	Transpose a csv file (assumes header at first column instead of rows)

=cut
sub transposeCsv {
	my $csvFilename = shift;
	open(CSV, $csvFilename) or die "Error: Can't open $csvFilename $!";
	my @csvArr =();
	foreach (<CSV>) {
		chomp;
		my @lineArr = m/\s*([^,"]+|"[^\"]+")\s*(?:,|$)/g;
		push (@csvArr, \@lineArr); 
	}
	for (my $col = 0; $col < @{$csvArr[0]}; ++$col){
		my $printLine = "";
		for (my $row = 0; $row < @csvArr; ++$row) {
			$printLine .= $csvArr[$row]->[$col].",";
		}
		chop $printLine;
		print $printLine."\n";
	}
	return;
}
		
1;