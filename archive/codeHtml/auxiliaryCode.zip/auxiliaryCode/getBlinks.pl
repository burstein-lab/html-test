#!/usr/bin/perl -w

use strict;

my $base = 52840257;
my $nGenes = 2942;
my $baseLine = 'http://www.ncbi.nlm.nih.gov/sutils/blink.cgi?pid=';
my $baseFile = 'blink.cgi?pid=';
my $path = '/groups/pupko/davidbur/Legionella/blink/';

my $allLpgFile = '/groups/pupko/davidbur/Legionella/all.lpg';

open(LPG,$allLpgFile) or die "can't open $allLpgFile";
my @allLpg = <LPG>;
chomp @allLpg;

for (my $i=0; $i < $nGenes; ++$i){
	my $gi = $base + $i;
	my $url = $baseLine.$gi;
	system("wget $url");
	my $blinkFile = $baseFile.$gi;
	system ("mv $blinkFile $path/$allLpg[$i]");

}
