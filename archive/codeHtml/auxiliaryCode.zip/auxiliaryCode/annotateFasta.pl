#!/usr/bin/perl

use strict;

my $SHORT_ORF = 200;

use lib '..';
use lib 'D:\workspace\theEffectorsMachine';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '/cygdrive/d/workspace/theEffectorsMachine';
use lpgTools;


############################# USAGE ##############################

@ARGV == 4 or die "USAGE: annotateFasta.pl <fasta file> <csv annotaion file> <hash key> <header RegExp>
fasta file - The one which header is going to be changed.
csv annotation file - with the annotation which will replace the header
hash key - used to find the correct record in the csv file
header RegExp - regular expression used to find the key in the header.
";
##################################################################

my($fastaFilename, $csvFilename, $key, $headerRegExp) = @ARGV;

# Read csv file to hash
my %annotHash = %{csvTools::readCsv2Hash($csvFilename, $key)};

open (FASTA, $fastaFilename) or die "ERROR: cannot open $fastaFilename for reading...";
foreach (<FASTA>) {
	#if header - change it according to csv annotation file
	if (/^>/ and /($headerRegExp)/) {
		print ">";
		my %csvLine = @{$annotHash{$1}};
		foreach (values %csvLine){print "$_\| "};
		print "\n";
	}
	#if not header - just print line.
	else {print};
}