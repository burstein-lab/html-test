#!/usr/bin/perl -w
#
# horizontalAppendMany.pl 
# =======================
# Receives many files and append them horizontally.
# There is specifinf a separator character is obligatory
#  

use strict;

use lib '/cygdrive/d/workspace/pupkoSVN/scripts';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib 'C:\workspace\pupkoSVN\scripts';

use FileHandle;
use util;

@ARGV > 1 or die "USAGE: horizontalAppend.pl > <separator character> <file_1> <file_2> .. <file_n>";

my($separator, @files) = @ARGV;

# open all files.
my @fhArr = map {new FileHandle($_) or die "can't open $_"} @files;
# read file lines and chomp
my @fhLinesArr = map {[<$_>]} @fhArr;
foreach (@fhLinesArr) {chomp @{$_}}; 

# Get max file length
my @lengthsArr = map {scalar @{$_}} @fhLinesArr;
my $maxlength = util::max(@lengthsArr);

for (my $iLine=0; $iLine <= $maxlength; $iLine++){
	my $printLine="";
	foreach (@fhLinesArr) {$printLine .= "$_->[$iLine]$separator" if defined $_->[$iLine]}
	chop $printLine;
	print "$printLine\n";
}
