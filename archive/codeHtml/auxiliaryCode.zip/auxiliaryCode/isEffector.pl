#!/usr/bin/perl -w

use strict;

use lib '..';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';

use MapTools;

@ARGV == 3 or die "USAGE: isEffector.pl <genes list> <effectors list> <non-effectors list>\n";

my($genesList, $effectorsList, $nonEffectorsList) = @ARGV;

# Read genes list
my @genesArr = MapTools::readList($genesList,'\d+');

# Read effecors list to => 1 hash 
my @effectorsArr = MapTools::readList($effectorsList,'\d+');
my %effectorsHash = map {$_ => "YES"} @effectorsArr;

# Read non-effecors list  to => 0 hash
my @nonEffectorsArr = MapTools::readList($nonEffectorsList,'\d+');
my %nonEffectorsHash = map {$_ => "NO"} @nonEffectorsArr;

# print putative value in hash 
print "\"effector?\"\n";
foreach (@genesArr) {
	if (defined $effectorsHash{$_}) {
		print $effectorsHash{$_};
	} elsif (defined $nonEffectorsHash{$_}) {
		print $nonEffectorsHash{$_};
	} else {
		print "?";	
	}
	print "\n";
};

