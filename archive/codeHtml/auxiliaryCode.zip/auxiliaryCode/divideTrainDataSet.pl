#!/usr/bin/perl -w

use strict;

use lib '..';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib '/cygdrive/d/workspace/theEffectorsMachine';
use lib '/cygdrive/d/workspace/pupkoSVN/scripts';
use lib 'C:\workspace\theEffectorsMachine';
use lib 'C:\workspace\pupkoSVN\scripts';
use lib 'D:\workspace\theEffectorsMachine';
use lib 'D:\workspace\pupkoSVN\scripts';

use csvTools;

@ARGV >= 2 or die "USAGE: divideTrainDataSet.pl <full set file> <training set list file> <data set list file> <training set filename> <data set filename> \n";

my($fullSet, $trainList, $dataList, $trainFilename, $dataFilename) = @ARGV;

my @arr= csvTools::printCsvSubset($fullSet, 'ORF', $trainList);
if ($trainFilename) {
	open(TRAIN,">$trainFilename") or die "Error: cannot open trainFilename";
	print TRAIN @arr;
	close(TRAIN);
}
if ($dataList && $dataFilename) {
	@arr= csvTools::printCsvSubset($fullSet, 'ORF', $dataList);
	open(DATA,">$dataFilename") or die "Error: cannot open $dataFilename";
	print DATA @arr;
	close(DATA);
}
