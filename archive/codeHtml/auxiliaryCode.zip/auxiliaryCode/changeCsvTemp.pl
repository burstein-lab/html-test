#!/usr/bin/perl -w

use strict;

use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib 'C:\workspace\theEffectorsMachine';
use lib 'D:\workspace\theEffectorsMachine';

use lpgTools;

my %pssm = %{csvTools::prefixCol('C:\workspace\Legionella\annotation\lpgTigrMerged4.csv', 'C:\workspace\Legionella\annotation\MLeffectors at work.csv', 'Lpg', 'Symbol', '-' )};
csvTools::writeCsvHash('C:\workspace\Legionella\annotation\lpgTigrMerged5.csv',\%pssm,	['Lpg', 'TIGR', 'Start', 'End', 'F/R', 'Length', 'Short', 'aaLen', 'MW', 'Symbol', 'Description']);
