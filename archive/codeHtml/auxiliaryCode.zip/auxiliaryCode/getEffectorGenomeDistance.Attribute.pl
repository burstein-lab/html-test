#!/usr/bin/perl -w

use strict;

use lib '..';
use lib '../../';
use lib '/cygdrive/d/workspace/theEffectorsMachine';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib 'D:\workspace\pupkoSVN\scripts';
use lib 'C:\workspace\pupkoSVN\scripts';

use ReadGilsExcel;

use util;

@ARGV >= 3 or die "USAGE: getEffectorGenomeDistance.Attribute.pl <effectors list> <genes list> <genome size> [optional -F <effectors html file >]
-F: get full information (then effectors html file should be added)";

my($effectorsList, $genesList, $genomeSize, $fullData, $html) = @ARGV;
$fullData = ($fullData =~ /-[fF]/)? 1:0 if defined $fullData;

### read lpg description from html if on full data mode ###
my %lpgDescHash = ReadGilsExcel::readDesc2Hash($html) if $html;	

#### Read effectors list ####
open(EFFECTORS, $effectorsList) or die "Error: Can't open effectors list file $effectorsList $!";
my @effectorsArr = <EFFECTORS>;
chomp @effectorsArr;
# get number value of the array
@effectorsArr = map {/(\d+)/} @effectorsArr;

#### Read genes list ####
open(GENES, $genesList) or die "Error: Can't open genes list file $genesList $!";
my @genesArr = <GENES>;
chomp @genesArr;
# get number value of the array
@genesArr = map {/(\d+)/} @genesArr;

#### output distance from effector####
print "\"protein\"," if $fullData;
print "\"Distance from effector\"\n";
foreach my $gene (@genesArr){
	
	# weed out current gene if on effectors list (o/w all effectors will receive distance 0) 
	my @otherEffectorsArr = grep {!/$gene/} @effectorsArr;
	 
	# check minimum distace from each effector.
	# it is min( |gene-effector|, genomeSize-|gene - effector|)
	my @effectorsDistArr = map{util::min( abs($gene - $_), ($genomeSize)-abs($gene - $_) )} @otherEffectorsArr;
	# print out the distance of closest of the effectors
	my $minDistance = util::min(@effectorsDistArr);
	# If fullData flag on - print also the closest effector
	if ($fullData) {
		my($minIndex) = grep {$effectorsDistArr[$_] == $minDistance} 0..$#effectorsDistArr;
		my $effectorLpg = $otherEffectorsArr[$minIndex];
		print "lpg$effectorLpg";
		print ": $lpgDescHash{$effectorLpg}" if defined $lpgDescHash{$effectorLpg};
		print ",";
	}
	print $minDistance;
	print "\n";
}
