#!/usr/bin/perl -w
#
# getBestEvalue.Attribute.pl
# ================================== 
# Gets the best E-value of a each query of a given blast.
# If no hits exist for a query gives a provided 'missing-hit-value'
#
# Input: Blast file, 'missing hit value', effectors list, gene list
# Output: best e-value for each blast query
#

use strict;

use lib '..';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib '/cygdrive/d/workspace/pupkoSVN/scripts';
use lib '/cygdrive/c/Perl/site/lib/';


use Bio::SearchIO;

############################################## Usage ###################################################

@ARGV ==4  or die "USAGE: $0 <Blast file> <effectors list> <genes list> <threshold> 
The header names of the <Blast file> should be >lpgXXXX ";

########################################################################################################

my($blastFilename, $effectorsList, $genesList, $threshold) = @ARGV;

#### Read effectors list ####
open(EFFECTORS, $effectorsList) or die "Error: Can't open effectors list file $effectorsList $!";
# Read to array
my @effectorsArr = <EFFECTORS>;
close(EFFECTORS);
chomp @effectorsArr;
# Map array to hash
my %effectorsHash = map {$_ => 1} @effectorsArr;

#### Read genes list ####
open(GENES, $genesList) or die "Error: Can't open genes list file $genesList $!";
my @genesArr = <GENES>;
close(GENES);
chomp @genesArr;
# Map array to hash
my %genesHash = map {$_ => 1} @genesArr;

########## open Blast file / read from std input ########## 
my $blastInFH;
if ($blastFilename eq 'STDIN') {
	$blastInFH = new Bio::SearchIO(	-format => 'blast',
												-fh     => \*STDIN);
} else {
	$blastInFH = new Bio::SearchIO(	-format => 'blast',
										   	-file   => "$blastFilename")
		or die "Can't open $blastFilename: $!";
}

# print title for csv
print "\"score to best ranking effector\",\"# effector with eVal < $threshold\"\n";
########## Read Blast results and print best e-value/missing-hit-value ###########

while(my $result = $blastInFH->next_result) {
	my $queryLpg = $result->query_name();
	# continue only if the query is on the gene list.
	next unless $genesHash{$queryLpg};
	my $isHitFound = 0;	# tests whether a legal hit was found 
	my $hitsUnderThreshold = 0;
	while (my $hit = $result->next_hit){
		my $hitLpg = $hit->name();
		# if hit equals query - skip
		next if ($queryLpg eq $hitLpg);
		# skip unless hit is in effectors list
		next unless $effectorsHash{$hitLpg};
		my $hsp = $hit->next_hsp();
		#if reached this line - an effectors hit was found. acknowledge that and print the score
		if (not $isHitFound) {
			$isHitFound = 1;
			print ($hsp->score());
		}
		
		if ($hsp->evalue() <= $threshold) {
			++$hitsUnderThreshold;
		}else {last}
	}
	
	#print missing-hit-value if no relevan hit is found.
	if (not $isHitFound){
		print "0";
	}
	print ",$hitsUnderThreshold\n"; 
}
$blastInFH->close();
