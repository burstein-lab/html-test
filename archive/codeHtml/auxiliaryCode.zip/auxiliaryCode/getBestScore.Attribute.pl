#!/usr/bin/perl -w
#
# getBestEvalue.Attribute.pl
# ================================== 
# Gets the best E-value of a each query of a given blast.
# If no hits exist for a query gives a provided 'missing-hit-value'
#
# Input: Blast file, 'missing hit value'
# Output: best e-value for each blast query
#

use strict;

use lib '..';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '/cygdrive/d/workspace/theEffectorsMachine';
use lib '/cygdrive/c/Perl/site/lib/';


use Bio::SearchIO;
use ReadGilsExcel;

######################### Usage ##############################

@ARGV >= 2 or die "USAGE: $0 <Blast file> <missing hit value> 
[optional -F <effectors html file> -H -L <regExp list file> -T <title>]
-F: get full information (then effectors html file should be added)
-H: get full information (from fasta header)
-L: takes into account only queries which match a regExp of the list in the given file.
-T: specify title
Blast file can be \'STDIN\'\n";

##############################################################

my($blastFilename, $missingHitValue, @args) = @ARGV;

my $argStr = join(' ',@args);
my $fullData = ($argStr =~ /-[f]/i)? 1:0;
my $headerInfo = ($argStr =~ /-[h]/i)? 1:0;
my ($html) = $argStr =~ /-[f]\s*(\S+)/i;
my ($regExpList) = $argStr =~ /-[L]\s*(\S+)/i;
my ($title) = $argStr =~ /-[T]\s*(\S+)/i;
$title = 'eVal to most similar' if not $title;

### read lpg description from html if on full data mode ###
my %lpgDescHash = ReadGilsExcel::readDesc2Hash($html) if $fullData;	

### read regExp list file if -L provided.
my @regExpArr = (); 
if ($regExpList) {
	open(REGEXP,$regExpList) or die "ERROR: cannot open regExp list file: $regExpList";
	@regExpArr = <REGEXP>;
	chomp @regExpArr;
}

########## open Blast file / read from std input ########## 
my $blastInFH;
if ($blastFilename eq 'STDIN') {
	$blastInFH = new Bio::SearchIO(	-format => 'blast',
												-fh     => \*STDIN);
} else {
	$blastInFH = new Bio::SearchIO(	-format => 'blast',
										   	-file   => "$blastFilename")
		or die "Can't open $blastFilename: $!";
}

# print title for csv
print '"protein",' if $fullData or $headerInfo;
print "\"$title\"";
print "\n";

########## Read Blast results and print best e-value/missing-hit-value ###########

while(my $result = $blastInFH->next_result ) {
	my $queryHeader = $result->query_name()." ".$result->query_description();
	# Skip if -L provided and not in list
	if ($regExpList) {
		my $skip = 1;
		foreach (@regExpArr){
			if ($queryHeader =~ /$_/) {
				$skip =0;
				last
			}
		} 
		next if ($skip);
	}

	if( my $hit = $result->next_hit) {		
		my $hitHeader = $hit->name().$hit->description();
		# Skip to next hit if hit = query 
		if (($result->query_name() eq $hit->name()) ) { 
			$hit = $result->next_hit; 
		}
		# If full data print the lpg of the best Evalue.
		if ($fullData && defined $hit->description()) {
			my ( $lpg ) = $hit->description() =~ /lpg(\d+)/;
			print "lpg$lpg";
			print ": $lpgDescHash{$lpg}" if defined $lpgDescHash{$lpg};
			print ","; 
		}
		if ($headerInfo) {print "\"$hitHeader\","}
	
		# if hit exist print its e-value otherwise print missing-hit-value
		print ($hit->next_hsp->score());
		# print ($hit->significance());
	}
	else {
		print "-," if $fullData or $headerInfo;
		print $missingHitValue;
	}
	print "\n"; 
}
$blastInFH->close();
