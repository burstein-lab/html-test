#!/usr/bin/perl -w

use strict;

use lib '..';
use lib '../../';
use lib '/cygdrive/d/workspace/theEffectorsMachine';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib 'D:\workspace\pupkoSVN\scripts';
use lib 'C:\workspace\pupkoSVN\scripts';

use ReadGilsExcel;

use util;

@ARGV >= 4 or die "USAGE: getEffectorGenomeDensity.Attribute.pl <effectors list> <genes list> <genome size> <range> [optional -F <effectors html file >]
range specifies how many ORFs to check 5' and 3' from the ORF in question.
-F: get full information (then effectors html file should be added)";

my($effectorsList, $genesList, $genomeSize, $range, $fullData, $html) = @ARGV;
$fullData = ($fullData =~ /-[fF]/)? 1:0 if defined $fullData;

### read lpg description from html if on full data mode ###
my %lpgDescHash = ReadGilsExcel::readDesc2Hash($html) if $fullData;	

#### Read effectors list ####
open(EFFECTORS, $effectorsList) or die "Error: Can't open effectors list file $effectorsList $!";
my @effectorsArr = <EFFECTORS>;
chomp @effectorsArr;
# get number value of the array
@effectorsArr = map {/\w{3}0*(\d+)/} @effectorsArr;
my %effectorsHash = map{$_ => 1} @effectorsArr;


#### Read genes list ####
open(GENES, $genesList) or die "Error: Can't open genes list file $genesList $!";
my @genesArr = <GENES>;
chomp @genesArr;
# get number value of the array
@genesArr = map {/lpg0*(\d+)/} @genesArr;

#### output distance from effector####
print "\"#effectors $range away\"\n";
my $hitsCount;
foreach my $gene (@genesArr){
	$hitsCount =0;
	# check +1/-1 +2/-2 .... +range/-range
	for (my $dist = 1; $dist <= $range; ++$dist){
		++$hitsCount if defined $effectorsHash{ ( ($gene + $dist) % $genomeSize ) };
		++$hitsCount if defined $effectorsHash{ ( ($gene - $dist) % $genomeSize ) };
	}
	print $hitsCount;
	print "\n";
}
