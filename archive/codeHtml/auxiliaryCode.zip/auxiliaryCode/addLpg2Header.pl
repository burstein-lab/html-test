#!/usr/bin/perl -w

use strict;

use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib 'C:\workspace\theEffectorsMachine';
use lib 'D:\workspace\theEffectorsMachine';
use lib '..';
use lpgTools;

@ARGV == 2 or die "USAGE: $0 <fasta file> <map file>";

my($fastaFile, $mapFile) = @ARGV;

# Read map from map file.
my @lpgMap=();
open(MAP, $mapFile) or die "Can't open $mapFile: $!";
while (<MAP>) {
	if (/(\d+)\s(\d+)/){
		$lpgMap[$1]=$2;
	}
}
close(MAP);


# Read Fasta file and print line with lpg instead of description
open(FASTA, $fastaFile) or die "Can't open $fastaFile: $!";
my $iLpg = 0;
while (<FASTA>) {
	if (m/(^>\S+)\s(.*)/) {
		my $lpgStr = lpgTools::lpgString($lpgMap[$iLpg]); 
		s/(^>\S+)\s(.*)/$1 $lpgStr $2/; 
		++$iLpg;
	}
	print;
}
close(FASTA);


