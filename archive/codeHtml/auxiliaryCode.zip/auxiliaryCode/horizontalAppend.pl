#!/usr/bin/perl -w
#
# horizontalAppend.pl 
# ===================
# Receives two files and append them horizontally.
# There is an option to specify a separator character (default is space)
#  

use strict;

use lib '/cygdrive/d/workspace/pupkoSVN/scripts';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib 'C:\workspace\pupkoSVN\scripts';

use util;

@ARGV > 1 or die "USAGE: horizontalAppend.pl > <file1> <file2> [optional: <separator character>]
Default separator is space
one of the two files can be 'STDIN'\n";

my($file1, $file2, $separator) = @ARGV;
$separator = ' ' unless defined $separator;
print "Error: Can't receive both files from STDIN" if (($file1 eq 'STDIN') && ($file2 eq 'STDIN'));

# Read file1
my @file1Arr = ();
if ($file1 eq 'STDIN') {@file1Arr = <STDIN>}
else {
	open(FILE1, $file1) or die "Error: Can't open $file1: $!";
	@file1Arr = <FILE1>;
}
chomp @file1Arr;
close FILE1;

# Read file2
my @file2Arr = ();
if ($file2 eq 'STDIN') {@file2Arr = <STDIN>}
else {
	open(FILE2, $file2) or die "Error: Can't open $file2: $!";
	@file2Arr = <FILE2>;
}
chomp @file2Arr;
close FILE2;

for (my $i=0; $i < util::max(scalar @file1Arr, scalar @file2Arr); $i++){
	print $file1Arr[$i] if defined $file1Arr[$i];
	print "$separator" if (defined $file1Arr[$i] && defined $file2Arr[$i]);
	print $file2Arr[$i] if defined $file2Arr[$i];
	print "\n";
}
