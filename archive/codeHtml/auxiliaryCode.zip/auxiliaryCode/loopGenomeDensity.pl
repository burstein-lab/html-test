#!/usr/bin/perl -w

use strict;

@ARGV >=6 or die "USAGE: getEffectorGenomeDensity.Attribute.pl <effectors list> <genes list> <genome size> <range max> <working directory> <base name> <isEffector file>
the script iterates from 1 to range max.
all the other parameters are passed to the getEffectorGenomeDensity script.";

my($effectorsList, $genesList, $genomeSize, $rangeMax, $baseName, $scriptsDir, $machineDir) = @ARGV;


foreach my $range (1..$rangeMax){
	system(" $machineDir/getEffectorGenomeDensity.Attribute.pl $effectorsList  $genesList $genomeSize $range > $baseName.$range");
}

my $appendString = "$scriptsDir/horizontalAppendMany.pl , ";
foreach my $range (1..$rangeMax){
	$appendString .= "$baseName.$range ";
}

$appendString .= " > $baseName.1-$rangeMax.csv ";
system($appendString);
