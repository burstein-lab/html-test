#!/usr/bin/perl

use strict;

my $SHORT_ORF = 200;

use lib 'C:\workspace\theEffectorsMachine';
use lib 'D:\workspace\theEffectorsMachine';
use lpgTools;

@ARGV == 4 or die "USAGE: tableMerge.pl <Tigr csv file> <columbia lpg file> <Gil's Csv file> <output filename>";
my($tigrCsvFilename, $lpgCsvFilename, $gilCsvFilename, $outFilename) = @ARGV;

# Read csv files.
my @tigrCsv = @{csvTools::readCsv($tigrCsvFilename)};
my @lpgCsv  = @{csvTools::readCsv($lpgCsvFilename)};
my @gilCsv  = @{csvTools::readCsv($gilCsvFilename)};
my @mergedCsv;

# Turn lpg and gil's to hashes with lpg as key
my %tigrHash = map {$_->{'Lpg'} => $_} @tigrCsv;
my %lpgHash  = map {$_->{'Lpg'} => $_} @lpgCsv;
my %gilHash  = map {$_->{'Lpg'} => $_} @gilCsv;

my $currLpg = 0;
my $currLpgStr = lpgTools::lpgString($currLpg);
my $subLpg = 1;
my $lastTigr = "NT04LP0000";
my $tigrSubNo = 1;

foreach my $tigrLine (@tigrCsv) {
	my %tigrLineHash = %{$tigrLine};
	
	# if lpg appear in gil's table update symbol.
	if (defined $gilHash{$tigrLineHash{'Lpg'}}) {
		$tigrLineHash{'Symbol'} = $gilHash{$tigrLineHash{'Lpg'}}{'Symbol'};
	}
	
	# add 'F\R'.
	$tigrLineHash{'F/R'} = ($tigrLineHash{'Start'} < $tigrLineHash{'End'})? 'F' : 'R';
	
	# add Short? for ORFs shorter than SHORT_ORF
	$tigrLineHash{'Short'} = ($tigrLineHash{'Length'}< $SHORT_ORF)? "***" :  "";
	
	# add lpg if no lpg defined for raw
	if (!defined $tigrLineHash{'Lpg'} || $tigrLineHash{'Lpg'} eq '') { 
		$tigrLineHash{'Lpg'} = $currLpgStr.".".$subLpg++;
	}
	# update current lpg and subLpg.	
	else {
		$currLpg++; 
		$currLpgStr = lpgTools::lpgString($currLpg); 
		$subLpg = 1;
		
		#if Tigr is missing some lpgs insert them
		$tigrSubNo = 1;
		while  ($currLpgStr lt $tigrLineHash{'Lpg'} and not defined $tigrHash{$currLpgStr}) {
			# compute length (will be needed to check if short + insert length).
			my $lpgLength = $lpgHash{$currLpgStr}{'End'} - $lpgHash{$currLpgStr}{'Start'} +1;
			
			push(@mergedCsv, {	'Lpg' 	=> $lpgHash{$currLpgStr}{'Lpg'}	,
										'TIGR' 	=> $lastTigr.".".$tigrSubNo++	,
										'Start'  => ($lpgHash{$currLpgStr}{'F/R'} eq 'F')? $lpgHash{$currLpgStr}{'Start'}: $lpgHash{$currLpgStr}{'End'} ,
										'End'  	=> ($lpgHash{$currLpgStr}{'F/R'} eq 'F')? $lpgHash{$currLpgStr}{'End'}: $lpgHash{$currLpgStr}{'Start'} ,
										'F/R'		=> $lpgHash{$currLpgStr}{'F/R'} ,
										'Description' =>  $lpgHash{$currLpgStr}{'Description'} ,
										'Symbol'	=> (defined $gilHash{$currLpgStr})? $gilHash{$currLpgStr}{'Symbol'} : $lpgHash{$currLpgStr}{'Symbol'},
										'Length' => $lpgLength ,
										'Short'	=> ($lpgLength < $SHORT_ORF)? "***" :  "" ,
										'aaLen'	=> $lpgHash{$currLpgStr}{'aaLen'} ,
										'MW'		=> undef});
				
				
			$currLpg++;
			$currLpgStr = lpgTools::lpgString($currLpg)
		}
	}
	push(@mergedCsv, \%tigrLineHash);
	$lastTigr = $tigrLineHash{'TIGR'}
}
# Its not pretty but this section takes care of the last line(s) 
$currLpg++; 
$currLpgStr = lpgTools::lpgString($currLpg);
$tigrSubNo =1;
while  (defined $lpgHash{$currLpgStr}) {
	# compute length (will be needed to check if short + insert length).
	my $lpgLength = $lpgHash{$currLpgStr}{'End'} - $lpgHash{$currLpgStr}{'Start'} +1;

	push(@mergedCsv, {	'Lpg' 	=> $lpgHash{$currLpgStr}{'Lpg'}	,
								'TIGR' 	=> $lastTigr.".".$tigrSubNo++	,
								'Start'  => ($lpgHash{$currLpgStr}{'F/R'} eq 'F')? $lpgHash{$currLpgStr}{'Start'}: $lpgHash{$currLpgStr}{'End'} ,
								'End'  	=> ($lpgHash{$currLpgStr}{'F/R'} eq 'F')? $lpgHash{$currLpgStr}{'End'}: $lpgHash{$currLpgStr}{'Start'} ,
								'F/R'		=> $lpgHash{$currLpgStr}{'F/R'} ,
								'Description' =>  $lpgHash{$currLpgStr}{'Description'} ,
								'Symbol'	=> (defined $gilHash{$currLpgStr})? $gilHash{$currLpgStr}{'Symbol'} : $lpgHash{$currLpgStr}{'Symbol'},
								'Length' => $lpgLength ,
								'Short'	=> ($lpgLength < $SHORT_ORF)? "***" :  "" ,
								'aaLen'	=> $lpgHash{$currLpgStr}{'aaLen'} ,
								'MW'		=> undef});
	$currLpg++; 
	$currLpgStr = lpgTools::lpgString($currLpg);
}

csvTools::writeCsv($outFilename, \@mergedCsv, ['Lpg', 'TIGR', 'Start', 'End', 'F/R', 'Length', 'Short', 'aaLen', 'MW', 'Symbol', 'Description']);





