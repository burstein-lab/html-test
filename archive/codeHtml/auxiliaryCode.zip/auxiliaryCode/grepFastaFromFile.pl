#!/usr/bin/perl -w

# TODO: include bioPerl, 


use strict;
use Bio::SeqIO;


@ARGV >= 2 or die "USAGE: $0 <fasta file> <expression list file> [-O -P <pattern> <replacement>]
Expression file should include list of expression, one on each line.
The script will output all fasta sequences which contains any of the expression in its header
Note: expression can be PERL regular expression = )
-O: only one line sequence (with no header) should be printed
-P <sequence substitute regExp> - regExp applied on each one of the ouputted sequences
                                  should be of the format s/PATTERN/REPLACEMENT/egimosx";

my($fastaFile, $expressionFile, @params) = @ARGV;
my ($onelineFlag, $seqSubPattern) = (0,undef);
# Parse extra paramteres
my $paramStr = join(' ',@params);
if ($paramStr =~ /\-O/i){$onelineFlag = 1};
if ($paramStr =~ /\-P\s(\S+)/) {$seqSubPattern = $1};


# Open fasta file and output to STDOUT
my $fastaIn = Bio::SeqIO->new(-file => $fastaFile, -format => 'fasta') or die "Error: Can't open $fastaFile: $!";
my $fastaOut = Bio::SeqIO->new(-fh	 => \*STDOUT,	 -format => 'fasta') or die "Error: Problems writeing to STDIO: $!";

# Open expression file and extract expression to array
open(EXP,$expressionFile) or die "Error: Can't open $expressionFile: $!";
my @expArr = <EXP>;
chomp @expArr; 
close(EXP);

# Pass through sequences of fasta file
my ($currSeq,$header,$seq); 
while ($currSeq = $fastaIn->next_seq()) {
	$seq = $currSeq->seq();

	# check whether header fits one of the expression
	foreach my $exp (@expArr) {
		$header = $currSeq->primary_id()." ".$currSeq->desc();
		# check for expression in header.
		if ($header =~ /$exp/) {
			
			# apply substitution on sequence
			if (defined $seqSubPattern){
				 eval('$seq =~ '.$seqSubPattern);
			}
			
			# in case of one line flag 
			if ($onelineFlag) {
				print($seq."\n");
			# in any other case - print out sequence
			} else {
				$currSeq->seq($seq);
				$fastaOut->write_seq($currSeq);			
			}
		}
	}
}

