#!/usr/bin/perl -w

use strict;

use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib 'C:\workspace\theEffectorsMachine';
use lib 'D:\workspace\theEffectorsMachine';
use lib '..\..\pupkoSVN\scripts';
use lib '..';

use util;
use lpgTools;
use Bio::SeqIO;

my $VERY_LARGE_NUM = 6e66;
my $VERY_SMALL_NUM = -1 * $VERY_LARGE_NUM;
my $PRETTY_SMALL_NUMBER = $VERY_SMALL_NUM /2; 
######################### Usage ##############################
@ARGV >= 4 or die "USAGE: getTFbind.Attribute.pl <pssm file> <fasta file> <title> <substr OFFSET> <substr LENGTH>
<pssm file> - pssm can be csv or tab/space delimited.
<fasta file> - fasta file containing all genes that needs to be tested 
<title> the title of the PSSM scores gathered
<substr OFFSET> - OFFSET parameter send to the substr function applied on each sequence 
";
##############################################################

my ($pssmFile, $fastaFilename, $title, $seqOffset) = @ARGV;


# Read pssm.
my %pssm = %{PssmTools::readPssm($pssmFile)};

# Get pssm length (though all the char should have the same size in it the minimal array length assign to a character).
my $pssmLength = util::min(map {scalar @{$_}} (values %pssm) );
my $nPssmChars = scalar keys %pssm;

# Read Fasta file.
my $fastaFile = Bio::SeqIO->new(-file   => "<$fastaFilename", -format => 'fasta' );
print "\"$title\"\n";


# Iterate over each sequence
while (my $seq = $fastaFile->next_seq) {
	#get subsequence according to offset
	my $subSeq = substr($seq->seq(),$seqOffset);
	my $seqLength = length($subSeq); 
	my @subSeqArr = split(//,$subSeq);
	
	my $pssmBestScore = undef;
	# Slide a sliding window for each possible pssm over the sub-string
	for (my $iRegionChar = 0; $iRegionChar < $seqLength - $pssmLength + 1; ++$iRegionChar){
		
		my $currPssmScore = 0; 
		# pass over all the pssm characters (inside the sliding window) 
		for (my $iPssmChar = 0; $iPssmChar < $pssmLength; ++$iPssmChar){
			my $currChar = $subSeqArr[$iRegionChar+$iPssmChar];
			
			# if the probabilty of the current char is 0 return undef (should not happen when using pseudo counts to build the pssm)
			if ($pssm{$currChar}[$iPssmChar] == 0) {
				warn "Encountered 0 value in psssm (pos: $iPssmChar; char:$currChar)";
				$currPssmScore =  $VERY_SMALL_NUM
			}
			else { $currPssmScore += log($pssm{$currChar}[$iPssmChar]) + log($nPssmChars)}; # log($nPssmChars) = - log(1/$nPssmChars)
			
		}
		# best score is the best so far or the first. 
		$pssmBestScore = (defined $pssmBestScore)? util::max($pssmBestScore, $currPssmScore) : $currPssmScore;
	}
	# The best score is the max of the best and the current (unless the cureent is not defined - ther was a zero probability).
	print $pssmBestScore;
	print "\n";	 
	
}





