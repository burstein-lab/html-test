#!/usr/bin/perl

use strict;

use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib 'C:\workspace\theEffectorsMachine';
use lib 'D:\workspace\theEffectorsMachine';

use PssmTools;

@ARGV >= 1 or die "USAGE: reversePssm.pl <pssm file>
prints a reverse complment of a pssm file ";

my($pssmFile) = @ARGV;
PssmTools::revcomPssm($pssmFile);

