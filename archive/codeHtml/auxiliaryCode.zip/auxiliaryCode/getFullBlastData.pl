#!/usr/bin/perl -w
#
# getFullBlastData.ppl
# ================================== 
# Gets the Data of the highest ranking blast hit of a each query of a given blast.
# If no hits exist for a query gives a provided 'missing-hit-value'
#
# Input: Blast file, 'missing hit value', effectors list, gene list
# Output: Blast data for the best ranking hit 
#

use strict;

use lib '..';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib '/cygdrive/d/workspace/pupkoSVN/scripts';
use lib '/cygdrive/c/Perl/site/lib/';


use Bio::SearchIO;

############################################## Usage ###################################################

@ARGV == 1  or die "USAGE: $0 <Blast file>";


########################################################################################################

my($blastFilename, $effectorsList) = @ARGV;

########### open Blast file / read from std input ########## 
my $blastInFH;
if ($blastFilename eq 'STDIN') {
	$blastInFH = new Bio::SearchIO(	-format => 'blast',
												-fh     => \*STDIN);
} else {
	$blastInFH = new Bio::SearchIO(	-format => 'blast',
										   	-file   => "$blastFilename")
		or die "Can't open $blastFilename: $!";
}

# print title for csv
print "\"ORF\",\"e-value\",\"score\",\"% identical\",\"% conserved\",\"description\"\n";
########## Read Blast results and print best e-value/missing-hit-value ###########

while(my $result = $blastInFH->next_result) {
	my $queryHeader = $result->query_name()." ".$result->query_description();
	my ($lpg) =  ($queryHeader =~ /(lpg\d+)/);
	if (my $hit = $result->next_hit()) {
		my $hsp = $hit->next_hsp();
		print $lpg.",".$hsp->evalue().",".$hsp->score().",".100*$hsp->frac_identical('total').",".100*$hsp->frac_conserved('total').",\"".$hit->name().$hit->description()."\"\n";
	}
	else {print "$lpg,-,-,-,-,\"-\"\n"};
}	 
$blastInFH->close();

		
