###################################################################
# Input: genome fasta file, ptt file (from ncbi), list of gi
# Output: G+C content of the gi listed
#
#
####################################################################


#!/usr/bin/perl -w

use strict;
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '..';

use Bio::SeqIO;
use MapTools;

@ARGV == 3 or die "USAGE: $0 <fasta genome file> <ptt file> <GI list>";

my($genomeFastaFilename, $pttFile, $giList) = @ARGV;

### read gi list file  to hash
my @giArr = (); 
open(GI,$giList) or die "ERROR: cannot open GI list file: $giList";
@giArr = <GI>;
chomp @giArr;
my %giHash = map{$_ => 1} @giArr;
close(GI);

# print header 
print "\"GC content\"\n";


# Read genome Fasta file and read genome
my $genomeFastaSeq = Bio::SeqIO->new(-file   => "<$genomeFastaFilename",
        		                    -format => 'fasta' );
my $genomeSeq = $genomeFastaSeq->next_seq->seq();


# Go through the lines of the ptt file.
open(PTT,$pttFile) or die "ERROR: cannot open ptt file: $pttFile";

my ($start,$stop,$gi,$geneSeq,$gcCount, $atCount);
while (<PTT>){
	chomp;
	# get start stop and gi
	if (m/(\d+)\.\.(\d+)\s+[\+\-]\s+\d+\s+(\d+)/){
		($start,$stop,$gi) = ($1, $2, $3);
		
		# for gi in list - get gene sequence (or reverse complement - does not change G+C-wise)
		if (defined $giHash{$gi}) {
			$geneSeq = substr($genomeSeq, $start-1, $stop-$start+1);
			
			# count G+C and print 
			($gcCount, $atCount) = (0,0); 
			$gcCount = ($geneSeq =~ tr/GCgc//);
			$atCount = ($$geneSeq =~ tr/ATat//);
			print ($gcCount/($gcCount+$atCount));
			print "\n";
		}
	}
}