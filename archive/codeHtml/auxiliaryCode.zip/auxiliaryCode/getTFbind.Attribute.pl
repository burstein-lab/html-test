#!/usr/bin/perl -w

use strict;

use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib 'C:\workspace\theEffectorsMachine';
use lib 'D:\workspace\theEffectorsMachine';

use lpgTools;

my $VERY_LARGE_NUM = 6e66;
my $VERY_SMALL_NUM = -1 * $VERY_LARGE_NUM;
my $PRETTY_SMALL_NUMBER = $VERY_SMALL_NUM /2; 
######################### Usage ##############################
@ARGV >= 8 or die "USAGE: getTFbind.Attribute.pl <pssm file> <pure genome file> <coordinates csv file> <key column> <gene list file> <upstream> <downstream> <title> <params>
<pssm file> - pssm can be csv or tab/space delimited.
<pure genome file> - should contain nothing but the genome sequence: no header no '>' nothing. 
<coordinates csv file> - should be cvs which contains a 'Start' and 'F/R'column.
<key column> - The header of the column of the annotation file which has the gene names   
<gene list file> - file containg the genes for which the attribute should be checked.
<upstream> - number of nuc' upstream the translation start
<downstream> - number of nuc' downstream the translation start
<title> the title of the TF binding site
<params> - are optional: 
			-L give location of the best score. 
			-S give sequence
			-R allow to check the reverse complement  
";
##############################################################


my($pssmFile, $pureGenomeFilename, $coordCsvFile, $key, $geneListFile, $upstream, $downstream, $title, @params) = @ARGV;


my $paramStr = join('',@params);
my ($printSeq, $printLocation, $allowReverse) = (0,0,0);
if ($paramStr =~ /\-S/i){$printSeq = 1};
if ($paramStr =~ /\-L/i){$printLocation = 1}; 
if ($paramStr =~ /\-R/i){$allowReverse = 1};

# Read files.
my %pssm = %{PssmTools::readPssm($pssmFile)};
open(GENOME,$pureGenomeFilename ) or die "Error: Cannot open genome file $pureGenomeFilename for reading<BR>\n";
my %lpgCoordHash = %{csvTools::readCsv2Hash($coordCsvFile, $key)};
open(GENES,$geneListFile);

# If -R create reverse complement pssm
my %revPssm = ();
if ($allowReverse) {%revPssm = %{PssmTools::revcomPssm(\%pssm)}};

# Get pssm length (though all the char should have the same size in it the minimal array length assign to a character).
my $pssmLength = util::min(map {scalar @{$_}} (values %pssm) );
my $nPssmChars = scalar keys %pssm;

print "\"$title\"";
print ",\"sequence\"" if $printSeq;
print ",\"location\"" if $printLocation;
print "\n";

# loop over all the genes of the list
foreach (<GENES>) {
	# get coordinates and read region sequence
	chomp;
	my %csvCoordLine = %{$lpgCoordHash{$_}} or die "ERROR: cannot find $_ in $coordCsvFile";
	my $isForward = ($csvCoordLine{'F/R'} =~ /F/i);
	
	# get region start (depend on direction) and sequence
	my $regionSeq;
	my $regionLength = $upstream + $downstream + 1;
	my $regionStart = $isForward? $csvCoordLine{'Start'} - $upstream : $csvCoordLine{'Start'} - $downstream; 
	seek(GENOME, $regionStart-1, 0) or die "Error wile seeking: $!";
	read(GENOME, $regionSeq, $regionLength) or die "Error while reading $regionLength char starting $regionStart from $pureGenomeFilename";  
	$regionSeq = util::revcom($regionSeq) if (not $isForward); 

	# Turn region to array
	my @regionArr = split(//,$regionSeq);
	
	my $pssmBestScore = $VERY_SMALL_NUM;
	my $revPssmBestScore = $VERY_SMALL_NUM;
	my $bestRegionChar;
	# Slide a sliding window for each possible pssm over the region
	for (my $iRegionChar = 0; $iRegionChar < $regionLength - $pssmLength + 1; ++$iRegionChar){
		
		my $currPssmScore; 
		my $revCurrPssmScore;
		if (not $allowReverse) {$revCurrPssmScore = $VERY_SMALL_NUM};
		# pass over all the pssm characters (inside the sliding window) 
		for (my $iPssmChar = 0; $iPssmChar < $pssmLength; ++$iPssmChar){
			my $currChar = $regionArr[$iRegionChar+$iPssmChar];
			
			# if the probabilty of the current char is 0 return $VERY_SMALL_NUM as score of the all pssm (should not happen when using pseudo counts to build the pssm)
			if (not $pssm{$currChar}[$iPssmChar]) {$currPssmScore =  $VERY_SMALL_NUM}
			else { $currPssmScore += log($pssm{$currChar}[$iPssmChar]) + log($nPssmChars)}; # log($nPssmChars) = - log(1/$nPssmChars)
			
			# same for reverse
			if ($allowReverse){
				if(not $revPssm{$currChar}[$iPssmChar]) {$revCurrPssmScore = $VERY_SMALL_NUM}
				else { $revCurrPssmScore += log($revPssm{$currChar}[$iPssmChar]) + log($nPssmChars)}; # log($nPssmChars) = - log(1/$nPssmChars)
			}
			# give up if both scores are no good
			last if ($currPssmScore  == $VERY_SMALL_NUM and $revCurrPssmScore == $VERY_SMALL_NUM)
		}
		
		# The best score is the max of the best and the current (unless the cureent is not defined - ther was a zero probability).
		$pssmBestScore = util::max($pssmBestScore, $currPssmScore, $revCurrPssmScore);	
		$bestRegionChar = $iRegionChar if ($pssmBestScore == $currPssmScore or $pssmBestScore == $revCurrPssmScore) 
	}
	my $finalScore = $pssmBestScore / $pssmLength;
	print $finalScore;
	
	# print sequence if required
	if ($printSeq) {
		print ",";
		my $printSeq;
		for (my $i = $bestRegionChar; $i < $bestRegionChar+$pssmLength; ++$i) {$printSeq .= $regionArr[$i]};
		print $printSeq;
		if ($allowReverse) {
			print " \\ ";
			print(util::revcom($printSeq));	
		}		
	}
	# print location if required
	if ($printLocation) {
		print ",";
		print($bestRegionChar - $upstream);
		print "..";
		print($bestRegionChar - $upstream + $pssmLength -1);
		
	}
	print "\n";
	
}








