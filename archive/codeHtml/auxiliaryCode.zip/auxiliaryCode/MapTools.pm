package MapTools;

use strict;

# Reads map file to array
# file include two columns: first for index second for value.
# possibly not on the begining and with characters before the number 
# 0   3
# 1   4
# 2   6 
# etc... 
sub readMap{
	my $mapFile = shift;
	# Read map from map file.
	my @Map=();
	open(MAP, $mapFile) or die "Can't open $mapFile: $!";
	while (<MAP>) {
		if (/(\d+)\s[a-zA-Z\s]*(\d+)/){
			$Map[$1]=$2;
		}
	}
	return @Map;
}

# receives an array and possibly index prefix and value prefix
# Print out array in map form.
# <index prefix><index>\t<value prefix><value>\n
sub printMap{
	my $mapFileRef = shift;
	my $iPrefix = shift;
	my $valPrefix =  shift;
	my $i =0;
	foreach my $val (@{$mapFileRef}){
		if (defined $val) {
			print $iPrefix if $iPrefix; 
			print $i++."\t".$val;
			print $valPrefix if $valPrefix;
			print "\n";
		}
	}
}

sub readList{
	my $listFilename = shift;
	my $regExp = shift;
	open(LIST, $listFilename) or die "Error: Can't open genes list file $listFilename $!";
	my @listArr = <LIST>;
	chomp @listArr;
	#get regExp of the array
	@listArr = map {/($regExp)/} @listArr if defined $regExp;
}
1;
