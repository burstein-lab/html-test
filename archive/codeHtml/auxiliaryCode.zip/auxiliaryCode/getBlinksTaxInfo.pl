#!/usr/bin/perl -w

use strict;

my $allLpgFile = '/groups/pupko/davidbur/Legionella/all.lpg';
my $blinkPath = '/groups/pupko/davidbur/Legionella/blink/';

open(LPG,$allLpgFile) or die "can't open $allLpgFile";
my @allLpg = <LPG>;
chomp @allLpg;

print '"ORF","Bacteria","Metazoa"';

foreach my $lpg (@allLpg){
	open(BLINK,$blinkPath.$lpg);
	my @currBlinkFile = <BLINK>;
	my @taxInfo = grep(/new tax_item/,@currBlinkFile);
	chomp @taxInfo;
	my ($bacteriaVal,$metazoaVal);
	foreach (@taxInfo){

		#	, new tax_item('2', 'Bacteria', 'ccffff', '', '2030')
		$bacteriaVal = $1 if (/\'Bacteria\',(?:.*?,\s*){2}\'(\d+)\'/);
		
		#	, new tax_item('33208', 'Metazoa', 'ffccff', '', '1')
		$metazoaVal = $1 if (/\'Metazoa\',(?:.*?,\s*){2}\'(\d+)\'/);
	}
	print "$lpg,$bacteriaVal,$metazoaVal\n";
	
}
