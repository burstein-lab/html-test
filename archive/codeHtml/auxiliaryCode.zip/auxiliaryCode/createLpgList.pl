#!/usr/bin/perl

use strict;

use lib '..';
use lib 'D:\workspace\theEffectorsMachine';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '/cygdrive/d/workspace/theEffectorsMachine';
use lpgTools;


############################# USAGE ##############################

@ARGV == 1 or die "USAGE: createLpgList.pl <lpg list>
Turns the given list to a sorted unique proper lpg list.
";
##################################################################

my($lpgFile) = @ARGV;

# Read file to array
open (LPG, $lpgFile) or die "ERROR: cannot open $lpgFile for reading...";
my @lpgArr = <LPG>;
close(LPG);

# array to hash (for uniqueness)
chomp @lpgArr;
my %lpgHash = ();
foreach (@lpgArr) {
	/lpg(\d+)/;
	my $lpgNum = 0 + $1;
	$lpgHash{$lpgNum}++;
};

# hash to sorted array + print 
foreach (sort  {$a <=> $b} keys %lpgHash) {print lpgString($_)."\n"};


