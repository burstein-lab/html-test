#!/usr/bin/perl -w

use strict;
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '..';

use Bio::SeqIO;
use MapTools;

@ARGV >= 1 or die "USAGE: $0 <nucleotide fasta file> <regExp list file>";

my($fastaFilename, $regExpList) = @ARGV;

### read regExp list file.
my @regExpArr = (); 
if ($regExpList) {
	open(REGEXP,$regExpList) or die "ERROR: cannot open regExp list file: $regExpList";
	@regExpArr = <REGEXP>;
	chomp @regExpArr;
}

my ($gcCount, $atCount) = (0,0);
# Read Fasta file print out header, and GC count, AT count, CG content.
my $fastaSeq = Bio::SeqIO->new(-file   => "<$fastaFilename",
        		                    -format => 'fasta' );

my $iSeq = 0;
print "\"GC content\"\n";
while (my $seq = $fastaSeq->next_seq) {
	my $fastaHeader = $seq->id." ".$seq->desc;
	if ($regExpList) {
		my $skip = 1;
		foreach (@regExpArr){
			if ($fastaHeader =~ /$_/) {
				$skip =0;
				last
			}
		} 
		next if ($skip);
	}
	my $seqString = $seq->seq();
	$gcCount = ($seqString =~ tr/GCgc//);
	$atCount = ($seqString =~ tr/ATat//);
	
	print ($gcCount/($gcCount+$atCount));
	print "\n";
}

