#!/usr/bin/perl -w
#
# getHitsUnderThreshold.Attribute.pl
# ================================== 
# Gets the number of blast hits below a given threshold.
# Input: Blast file, threshold
# Output: number of hits below threshold, a line for each blast query
#

use strict;

use lib '..';
use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib '/cygdrive/d/workspace/theEffectorsMachine';
use lib '/cygdrive/c/Perl/site/lib/';

use Bio::SearchIO;
use ReadGilsExcel;

@ARGV >=2 or die "USAGE: $0 <Blast file> <e-value threshold> [optional -<flag> <effectors html file >]
Flags can be:
-F: get full information (then effectors html file should be added)
-C: get full information + coordinates (then effectors html file should be added)
Blast file can be \'STDIN\'";

my($blastFilename, $threshold, $flag, $html) = @ARGV;
my $fullData = ($flag =~ /-[fFcC]/)? 1:0 if defined $flag;
my $coordinates = ($flag =~ /-[cC]/)? 1:0 if defined $flag;

### read lpg description from html if on full data mode ###
my %lpgDescHash = ReadGilsExcel::readDesc2Hash($html) if $fullData;	

########## open Blast file / read from std input ########## 
my $blastInFH;
if ($blastFilename eq 'STDIN') {
	$blastInFH = new Bio::SearchIO(	-format => 'blast',
												-fh     => \*STDIN);
} else {
	$blastInFH = new Bio::SearchIO(	-format => 'blast',
										   	-file   => "$blastFilename")
		or die "Can't open $blastFilename: $!";
}

########## Read Blast results and print hit count below threshold ###########
print "\"Effectors with e-value < 0.1\"\n";

while(my $result = $blastInFH->next_result ) {
	my $hitsCount = 0;
	my @effHitArr = ();
	my @effCoordinatesArr = ();
	
	while(my $hit = $result->next_hit ) {
		# Skip if hit = query 
		next if ($result->query_name() eq $hit->name()); 
		
		# If e-value below threshold - increment count
		if ($hit->significance() <= $threshold) {
			++$hitsCount;
			# keep lpg number if on fullData mode
			push @effHitArr, $hit->description() =~ /lpg(\d+)/;
			# get Hsp coordintes below threshold
			if ($coordinates) {
				my @hspRangeArr=();
				while (my $hsp = $hit->next_hsp()) {
					my @range = ($hsp->start('hit'),$hsp->end('hit'),$hsp->evalue());
					push(@hspRangeArr, \@range) if ($hsp->evalue() <= $threshold);					
				}
				push (@effCoordinatesArr, \@hspRangeArr);
			}
		}
	}
	print $hitsCount;
	if ($fullData) {
		for (my $iHit=0; $iHit <= $#effHitArr; ++$iHit) {
			print ","; 
			print "lpg$effHitArr[$iHit]"; 
			print": $lpgDescHash{$effHitArr[$iHit]}" if defined $lpgDescHash{$effHitArr[$iHit]}; 
			if ($coordinates) {
				foreach (@{$effCoordinatesArr[$iHit]}) {
					print ",($_->[0]..$_->[1]: $_->[2])"; 
				}
			}
		}
	}
	print "\n";
	@effHitArr=();

}
$blastInFH->close();
