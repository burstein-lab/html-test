#!/usr/bin/perl -w

# TODO: include bioPerl, 


use strict;

@ARGV >= 2 or die "USAGE: $0 <fasta file> <expression list file> [-O -P <perl regExp>]
Expression file should include list of expression, one on each line.
The script will output all fasta sequences which contains any of the expression in its header
Note: expression can be PERL regular expression = )
-O: only one line sequence (with no header) should be printed";

my($fastaFile, $expressionFile, @params) = @ARGV;
my ($onelineFlag, $seqRegExp) = (0,undef);
# Parse extra paramteres
my $paramStr = join('',@params);
if ($paramStr =~ /\-O/i){$onelineFlag = 1};
if ($paramStr =~ /\-P (\S+)/i){$seqRegExp = $1};


# Read expressionsi
open(EXP,$expressionFile) or die "Can't open $expressionFile: $!";
my @expArr = <EXP>;
chomp @expArr; 

# Read Fasta file and print lines after header with expression found.
my $isHeader = 1;
my $printFlag = 0;
my $fastaLine; 
open(FASTA, $fastaFile) or die "Can't open $fastaFile: $!";
while ($fastaLine = <FASTA>) {
	# If header 
	if ($fastaLine =~ /^>/) {
		# Reset print flag 
		$printFlag = 0;
		$isHeader = 1;
		 
		# If any expression is in the header set print flag on.
		foreach my $exp (@expArr) {
			if ($fastaLine =~ /$exp/) {
				$printFlag = 1;
			}
		} 
	} else {$isHeader = 0};
	if ($onelineFlag){
		chomp $fastaLine;
		$fastaLine = "\n" if $isHeader;
	}
	if ((defined $seqRegExp) && (not $isHeader) ) {
		
	}
	print $fastaLine if $printFlag;
}
close(FASTA);