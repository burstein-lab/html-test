package PssmTools;

use strict;

use lib '/groups/pupko/davidbur/pupkoSVN/trunk/scripts';
use lib '..\pupkoSVN\scripts';
use util;

=pod
buildPssm FILE PSEUDO_COUNTS REVERSE 
	
 Creates pssm out of provided sequences and print it out (csv format).
 Arguments:
 1. FILE - the name of the file containing the sequences
 2. PSEUDO_COUNTS number of pseduo-counts (default = 1)

=cut

sub buildPssm{
	my $seqFile = shift;
	my $pseudoCounts = shift;
	$pseudoCounts = 1 if not defined $pseudoCounts;
	
	#### Read sequences file ####
	open(SEQS, $seqFile) or die "Error: Can't open $seqFile $!";
	my @seqsArr = <SEQS>;
	chomp @seqsArr;
	
	#create matrix out of sequences
	my @seqsMat=();
	foreach (@seqsArr) {
		my @splittedSeq = split(//, $_);
		push(@seqsMat,\@splittedSeq);
	} 
	
	#### Build PSSM ####
	my @pssm = ();
	my %allCharHash = (); #chars of all seqeunces.
	
	# Get size of shortest sequence
	my $nChars = util::min(map {length($_) } @seqsArr );
	my $nSeqs = scalar @seqsArr;
	my $currChar;
	
	# build pssm for each position
	for (my $iChar = 0; $iChar < $nChars; ++$iChar) {
		
		my %countHash; # count of each char.
		for (my $iSeq = 0; $iSeq < $nSeqs; ++$iSeq) {
			$currChar = $seqsMat[$iSeq][$iChar];
		 	
		 	# Add to hash containing all chars..
		 	$allCharHash{$currChar} = 1; 
		 	
		 	# Increment char counter
		 	$countHash{$currChar} += 1;
		} 
		$pssm[$iChar] = \%countHash;
	}
	
	# Add psuedo counts and turn counts to probability.
	my $pseudoSum = scalar (keys %allCharHash) * $pseudoCounts;
	for (my $iChar = 0; $iChar < $nChars; ++$iChar) {
		foreach my $char (keys %allCharHash) {
			if ($pssm[$iChar]{$char}) {
				$pssm[$iChar]{$char} = ($pseudoCounts + $pssm[$iChar]{$char}) / ($nSeqs + $pseudoSum);
			} else {
				$pssm[$iChar]{$char} = $pseudoCounts / ($nSeqs + $pseudoSum);
			}
			  
		}
	} 

	foreach my $char (keys %allCharHash) {	
		print $char.",";
		for (my $iChar = 0; $iChar < $nChars; ++$iChar) {
			if (defined $pssm[$iChar]{$char}) {
				print $pssm[$iChar]{$char};
			}
			else {print "0"}
			
			print ",";
		}
		print "\n";			
	}
}

#
# Reads pssm in to following format:
#
# A , 1 , 0 , 0.2  0.4 0.1
# C   0   1 , 0.1, 0.5,0.8
# .
# .
# into the following:
# $pssm{A}[4] - what is the freq of A in the 5th position (zero based counting)
# (retuns a pointer to hash of chars pointing to array of freq)
sub readPssm{
	my $pssmFile = shift;
	my %pssm;
	open(PSSM, $pssmFile) or die "Error: Can't open $pssmFile $!";
	foreach (<PSSM>) {
#		print;
		if (/\s*\"*(\w)\"*[,\s]+(.*)/){
			my @freqArr = split(/[,\s]+/, $2);
			$pssm{$1} = \@freqArr;
		}
	}
	return(\%pssm);
}

=pod 
	
	revcomPssm PSSM_REF
	
	Reverse the pssm in PSSM_REF

=cut
sub revcomPssm{
	my $pssmRef = shift;
	my %revPssm;
	foreach (keys %{$pssmRef}){$revPssm{util::revcom($_)} = util::revcomArr	($pssmRef->{$_})}
	return \%revPssm;
}

1;