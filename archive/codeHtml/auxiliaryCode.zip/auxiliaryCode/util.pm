package util;

use strict;
use Exporter;
use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
$VERSION = 1.00;
@ISA = qw(Exporter);
@EXPORT      = qw(getAccessionOnly logVar printTime timeString revcom revcomArr overlapCoord min max);       # Symbols to autoexport (:DEFAULT tag)

use English qw( -no_match_vars );

use POSIX qw(strftime);
sub printTime {
	my $time = strftime "%Y %b %e %a %H:%M:%S", localtime(time());
	print "The time is: $time\n";
}

sub timeString {
	return strftime "%Y %b %e %a %H:%M:%S", localtime(time());
}

sub revcom {
	my $seq = shift;
	$seq = reverse $seq;
	$seq =~ tr/atgcATGC/tacgTACG/;
	return $seq;
}

sub revcomArr {
	my $seqArrRef = shift;
	my @seqArr = @{$seqArrRef};
	@seqArr = reverse @seqArr;
	foreach (@seqArr) {tr/atgcATGC/tacgTACG/};
	return \@seqArr;
}

=pod
Translates a nucleic acid sequence pattern to regular expression as follows (in addion it will accept any
ambiguous nucleotide that intesect with another nucleotide: For example W(eak) [AT] will also accept Y(pyrimidine) [CT] (because of the T)
	A \ a     [Aa]       Adenosine
	C \ c     [Cc]       Cytidine
    G \ g     [Gg]       Guanosine
    T \ t     [Tt]       Thymidine
    R \ r     [AaGg]     puRines
    Y \ y     [CcTt]     pYrimidines
    W \ w     [AaTt]     Weak hydrogen bonding
    S \ s     [GgCc]     Strong hydrogen bonding
    M \ m     [AaCc]     aMino group at common position
    K \ k     [GgTt]	  	 Keto group at common position
    H \ h     [AgCcTt]   not G
    B \ b     [GgCcTt]   not A
    V \ v     [GgAaCc]   not T
    D \ d     [GgAaTt]   not C
    N \ n     [GgAaCcTt] aNy  

=cut
sub ambiguousNuc2Regexp{
	my $seq = shift;
	my @seqArr = split(//,$seq );
	my @regExpArr;
	foreach (@seqArr) {
		push (@regExpArr,'[AaRrWwMmHhVvDdNn]') if (/A/i);
		push (@regExpArr,'[CcYySsMmHhBbVvNn]') if (/C/i);
		push (@regExpArr,'[GgRrSsKkBbVvDdNn]') if (/G/i);
   		push (@regExpArr,'[TtYyWwKkHhBbDdNn]') if (/T/i);
		push (@regExpArr,'[AaGgRrWwSsMmKkHhBbVvDdNn]') if (/R/i);
	   	push (@regExpArr,'[CcTtYyWwSsMmKkHhBbVvDdNn]') if (/Y/i);
	   	push (@regExpArr,'[AaTtRrYyWwMmKkHhBbVvDdNn]') if (/W/i);
	   	push (@regExpArr,'[GgCcRrYySsMmKkHhBbVvDdNn]') if (/S/i);
	   	push (@regExpArr,'[AaCcRrYyWwSsMmHhBbVvDdNn]') if (/M/i);
	   	push (@regExpArr,'[GgTtRrYyWwSsKkHhBbVvDdNn]') if (/K/i);
	   	push (@regExpArr,'[AgCcTtRrYyWwSsMmKkHhBbVvDdNn]') if (/H/i);
	   	push (@regExpArr,'[GgCcTtRrYyWwSsMmKkHhBbVvDdNn]') if (/B/i);
	   	push (@regExpArr,'[GgAaCcRrYyWwSsMmKkHhBbVvDdNn]') if (/V/i);
	   	push (@regExpArr,'[GgAaTtRrYyWwSsMmKkHhBbVvDdNn]') if (/D/i);
	   	push (@regExpArr,'[GgAaCcRrTtYyWwSsMmKkHhBbVvDdNn]') if (/N/i);
	}
	return join ('',@regExpArr);
}

sub getAccessionOnly {
	my $name = shift @_;
	if ($name =~ m/\w*[A-Z]\w+\d+(\.\d+)?/) {
		return $&; #$MATCH
	} else {
		print "Error: can't find an accession in '$name'\n";
		return 'no accession';
	}
}

sub overlapCoord{
# Receives 4 coordinates:  <seq1 start coord> <seq1 end coord> <seq2 start coord> <seq2 end coord>
# Return (<start overlap coord>, <end overlap coord>)
# Return (-1, -1) if no overlap.
	@_ == 4 or die "overlapCoord requires 4 parameters: <seq1 start coord> <seq1 end coord> <seq2 start coord> <seq2 end coord>";
	
	my ($start1, $end1, $start2, $end2) = @_;
	#if no overlap return undef;
	return (undef,undef) if (($start2 > $end1) || ($start1 > $end2) || ($start1 > $end1) || ($start2 > $end2));
	return (max($start1, $start2), min($end1, $end2));
}

sub min{
	my $min = pop @_;
	my $val;
	while (defined ($val = pop @_)) {
		$min = ($val < $min)? $val : $min;
	}
	return $min;
}

sub max{
	my $max = pop @_;
	my $val;
	while (defined ($val = pop @_)) {
		$max = ($val > $max)? $val : $max;
	}
	return $max;
}


1;
