#!/usr/bin/perl

use strict;

use lib '/groups/pupko/davidbur/pupkoSVN/trunk/programs/theEffectorsMachine';
use lib 'C:\workspace\theEffectorsMachine';
use lib 'D:\workspace\theEffectorsMachine';

use PssmTools;

@ARGV >= 1 or die "USAGE: buildPssm.pl <sequnces file> [optional: <pseudo counts>]
The PSSM is built for the entire sequence (assuming a sequence in each line).
psuedo counts are added to each character (to disable use 0)";

my($seqFile, $pseduoCounts) = @ARGV;

PssmTools::buildPssm($seqFile, $pseduoCounts);

