#!/usr/bin/perl -w

use strict;

@ARGV == 1 or die "USAGE: createIndexVertexMap <protein table>";

my($annoFilename) = @ARGV;




# save all gene description (by order) in @genes
my $i=0;
my $lpg;
open(ANNO, $annoFilename) or die "Can't open $annoFilename: $!";
while (<ANNO>) {
	if (/lpg(\d{4})/){				# get description (until [..])
		$lpg = 0 + $1;
		print "$i\t$lpg\n";
		$i++;
	}
}
close(ANNO);

